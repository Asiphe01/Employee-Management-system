package com.ems.db;

import java.sql.*;
    
public class dbinitializer{
    
     public static void init() {
         
        try (Connection conn = DBConnection.getConnection()) {
            if (!tableExists(conn, "DEPARTMENTS")) createDepartments(conn);
            if (!tableExists(conn, "ROLES"))       createRoles(conn);
            if (!tableExists(conn, "EMPLOYEES"))   createEmployees(conn);
            if (!tableExists(conn, "PAYROLL"))     createPayroll(conn);
            seedIfEmpty(conn);
            System.out.println("Database initialised successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("DB init failed: " + e.getMessage(), e);
        }
    }
 
   
 
    private static boolean tableExists(Connection conn, String table)
            throws SQLException {
        DatabaseMetaData meta = conn.getMetaData();
        try (ResultSet rs = meta.getTables(null, null, table, new String[]{"TABLE"})) {
            return rs.next();
        }
    }
 
    private static void exec(Connection conn, String sql) throws SQLException {
        try (Statement st = conn.createStatement()) { st.execute(sql); }
    }
 
    
 
    private static void createDepartments(Connection conn) throws SQLException {
        exec(conn,
            "CREATE TABLE departments (" +
            "  department_id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
            "  dept_name     VARCHAR(100) NOT NULL," +
            "  dept_code     VARCHAR(10)  NOT NULL," +
            "  location      VARCHAR(100)," +
            "  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
            ")");
        exec(conn, "CREATE UNIQUE INDEX uq_dept_name ON departments(dept_name)");
        exec(conn, "CREATE UNIQUE INDEX uq_dept_code ON departments(dept_code)");
        System.out.println("Table DEPARTMENTS created.");
    }
 
    private static void createRoles(Connection conn) throws SQLException {
        exec(conn,
            "CREATE TABLE roles (" +
            "  role_id     INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
            "  role_name   VARCHAR(100) NOT NULL," +
            "  role_level  INT NOT NULL DEFAULT 1," +
            "  description VARCHAR(255)" +
            ")");
        exec(conn, "CREATE UNIQUE INDEX uq_role_name ON roles(role_name)");
        System.out.println("Table ROLES created.");
    }
 
    private static void createEmployees(Connection conn) throws SQLException {
        exec(conn,
            "CREATE TABLE employees (" +
            "  employee_id   INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
            "  first_name    VARCHAR(50)  NOT NULL," +
            "  last_name     VARCHAR(50)  NOT NULL," +
            "  email         VARCHAR(100) NOT NULL," +
            "  phone         VARCHAR(20)," +
            "  hire_date     DATE         NOT NULL," +
            "  department_id INT REFERENCES departments(department_id)," +
            "  role_id       INT REFERENCES roles(role_id)," +
            "  status        VARCHAR(20)  DEFAULT 'ACTIVE'," +
            "  created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP" +
            ")");
        exec(conn, "CREATE UNIQUE INDEX uq_emp_email ON employees(email)");
        System.out.println("Table EMPLOYEES created.");
    }
 
    private static void createPayroll(Connection conn) throws SQLException {
        exec(conn,
            "CREATE TABLE payroll (" +
            "  payroll_id   INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
            "  employee_id  INT          NOT NULL REFERENCES employees(employee_id) ON DELETE CASCADE," +
            "  basic_salary DECIMAL(12,2) NOT NULL," +
            "  allowances   DECIMAL(12,2) DEFAULT 0.00," +
            "  deductions   DECIMAL(12,2) DEFAULT 0.00," +
            "  pay_period   DATE          NOT NULL," +
            "  pay_status   VARCHAR(20)   DEFAULT 'PENDING'," +
            "  notes        VARCHAR(255)," +
            "  created_at   TIMESTAMP     DEFAULT CURRENT_TIMESTAMP" +
            ")");
        System.out.println("Table PAYROLL created.");
    }
 
   
 
    private static void seedIfEmpty(Connection conn) throws SQLException {
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM departments")) {
            rs.next();
            if (rs.getInt(1) > 0) return;
        }
        exec(conn, "INSERT INTO departments(dept_name,dept_code,location) VALUES " +
             "('Human Resources','HR','Head Office')," +
             "('Information Technology','IT','Floor 2')," +
             "('Finance','FIN','Floor 3')," +
             "('Operations','OPS','Warehouse')");
        exec(conn, "INSERT INTO roles(role_name,role_level,description) VALUES " +
             "('Junior Developer',1,'Entry-level developer')," +
             "('Senior Developer',3,'Senior developer')," +
             "('HR Manager',3,'Manages HR')," +
             "('Accountant',2,'Financial records')," +
             "('System Administrator',3,'IT infrastructure')");
        System.out.println("Seed data inserted.");
    }
}