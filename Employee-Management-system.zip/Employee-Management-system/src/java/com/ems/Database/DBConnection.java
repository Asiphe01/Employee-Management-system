package com.ems.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    private static final String URL = "jdbc:postgresql://localhost:5432/employee_system";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "Beach5618";

    public static Connection getConnection() {
        Connection con = null;

          try {
                Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
                connection = DriverManager.getConnection(DB_URL);
                connection.setAutoCommit(true);
                System.out.println("JavaDB connection established.");
            } catch (ClassNotFoundException e) {
                throw new SQLException("Derby driver not found. "
                        + "Add derby.jar to your classpath.", e);
            }
        }
        return connection;
    }
 
    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                // Shut down the embedded engine cleanly
                try {
                    DriverManager.getConnection(
                            "jdbc:derby:EMSDatabase;shutdown=true");
                } catch (SQLException se) {
                    // Derby always throws XJ015 on successful shutdown
                    if (!"XJ015".equals(se.getSQLState())) {
                        se.printStackTrace();
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

