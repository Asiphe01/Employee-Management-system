package com.ems.dao;


import ems.db.DBConnection;
import ems.model.Employee;
 
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
 
public class EmployeeDAO {
 
    private static final String BASE_SELECT =
        "SELECT e.*, d.dept_name, r.role_name " +
        "FROM employees e " +
        "LEFT JOIN departments d ON e.department_id = d.department_id " +
        "LEFT JOIN roles       r ON e.role_id       = r.role_id ";
 
    // ------------------------------------------------------------------ CREATE
    public boolean addEmployee(Employee emp) throws SQLException {
        String sql =
            "INSERT INTO employees(first_name,last_name,email,phone," +
            "hire_date,department_id,role_id,status) VALUES (?,?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emp.getFirstName());
            ps.setString(2, emp.getLastName());
            ps.setString(3, emp.getEmail());
            ps.setString(4, emp.getPhone());
            ps.setDate  (5, new java.sql.Date(emp.getHireDate().getTime()));
            setNullableInt(ps, 6, emp.getDepartmentId());
            setNullableInt(ps, 7, emp.getRoleId());
            ps.setString(8, emp.getStatus() != null ? emp.getStatus() : "ACTIVE");
            return ps.executeUpdate() > 0;
        }
    }
 
    // ------------------------------------------------------------------ READ ALL
    public List<Employee> getAllEmployees() throws SQLException {
        List<Employee> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(
                     BASE_SELECT + "ORDER BY e.last_name, e.first_name")) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }
 
    // ------------------------------------------------------------------ READ ONE
    public Employee getEmployeeById(int id) throws SQLException {
        String sql = BASE_SELECT + "WHERE e.employee_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }
 
    // ------------------------------------------------------------------ READ BY DEPT
    public List<Employee> getEmployeesByDepartment(int deptId) throws SQLException {
        List<Employee> list = new ArrayList<>();
        String sql = BASE_SELECT + "WHERE e.department_id=? ORDER BY e.last_name";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, deptId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }
 
    // ------------------------------------------------------------------ SEARCH
    public List<Employee> searchEmployees(String keyword) throws SQLException {
        List<Employee> list = new ArrayList<>();
        String sql = BASE_SELECT +
            "WHERE LOWER(e.first_name) LIKE ? " +
            "   OR LOWER(e.last_name)  LIKE ? " +
            "   OR LOWER(e.email)      LIKE ? " +
            "ORDER BY e.last_name";
        String kw = "%" + keyword.toLowerCase() + "%";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, kw); ps.setString(2, kw); ps.setString(3, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }
 
    // ------------------------------------------------------------------ UPDATE
    public boolean updateEmployee(Employee emp) throws SQLException {
        String sql =
            "UPDATE employees SET first_name=?,last_name=?,email=?,phone=?," +
            "hire_date=?,department_id=?,role_id=?,status=? WHERE employee_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emp.getFirstName());
            ps.setString(2, emp.getLastName());
            ps.setString(3, emp.getEmail());
            ps.setString(4, emp.getPhone());
            ps.setDate  (5, new java.sql.Date(emp.getHireDate().getTime()));
            setNullableInt(ps, 6, emp.getDepartmentId());
            setNullableInt(ps, 7, emp.getRoleId());
            ps.setString(8, emp.getStatus());
            ps.setInt   (9, emp.getEmployeeId());
            return ps.executeUpdate() > 0;
        }
    }
 
    // ------------------------------------------------------------------ DELETE
    public boolean deleteEmployee(int id) throws SQLException {
        String sql = "DELETE FROM employees WHERE employee_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
 
    // ------------------------------------------------------------------ helpers
    private void setNullableInt(PreparedStatement ps, int idx, int val)
            throws SQLException {
        if (val > 0) ps.setInt(idx, val);
        else         ps.setNull(idx, Types.INTEGER);
    }
 
    private Employee map(ResultSet rs) throws SQLException {
        Employee e = new Employee();
        e.setEmployeeId  (rs.getInt   ("employee_id"));
        e.setFirstName   (rs.getString("first_name"));
        e.setLastName    (rs.getString("last_name"));
        e.setEmail       (rs.getString("email"));
        e.setPhone       (rs.getString("phone"));
        e.setHireDate    (rs.getDate  ("hire_date"));
        e.setDepartmentId(rs.getInt   ("department_id"));
        e.setDepartmentName(rs.getString("dept_name"));
        e.setRoleId      (rs.getInt   ("role_id"));
        e.setRoleName    (rs.getString("role_name"));
        e.setStatus      (rs.getString("status"));
        return e;
    }
}
}
