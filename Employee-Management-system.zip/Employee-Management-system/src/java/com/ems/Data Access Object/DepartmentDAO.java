package com.ems.dao;

    
 import com.ems.db.DBConnection;
 import com.ems.model.Department;
 
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
 
public class DepartmentDAO {

    public boolean addDepartment(Department dept) throws SQLException {
        String sql = "INSERT INTO departments(dept_name, dept_code, location) VALUES (?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, dept.getDeptName());
            ps.setString(2, dept.getDeptCode());
            ps.setString(3, dept.getLocation());
            return ps.executeUpdate() > 0;
        }
    }
 
    
    public List<Department> getAllDepartments() throws SQLException {
        List<Department> list = new ArrayList<>();
        String sql = "SELECT * FROM departments ORDER BY dept_name";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }
 
    
    public Department getDepartmentById(int id) throws SQLException {
        String sql = "SELECT * FROM departments WHERE department_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }
 
   
    public boolean updateDepartment(Department dept) throws SQLException {
        String sql = "UPDATE departments SET dept_name=?, dept_code=?, location=? " +
                     "WHERE department_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, dept.getDeptName());
            ps.setString(2, dept.getDeptCode());
            ps.setString(3, dept.getLocation());
            ps.setInt   (4, dept.getDepartmentId());
            return ps.executeUpdate() > 0;
        }
    }
 
   
    public boolean deleteDepartment(int id) throws SQLException {
        String sql = "DELETE FROM departments WHERE department_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
 
    public List<Department> searchDepartments(String keyword) throws SQLException {
        List<Department> list = new ArrayList<>();
        String sql = "SELECT * FROM departments " +
                     "WHERE LOWER(dept_name) LIKE ? OR LOWER(dept_code) LIKE ? " +
                     "ORDER BY dept_name";
        String kw = "%" + keyword.toLowerCase() + "%";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, kw); ps.setString(2, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }
 
    
    //Move an employee into this department */
    public boolean assignEmployee(int departmentId, int employeeId) throws SQLException {
        String sql = "UPDATE employees SET department_id=? WHERE employee_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, departmentId);
            ps.setInt(2, employeeId);
            return ps.executeUpdate() > 0;
        }
    }
 
    // Remove an employee from their department (set to NULL) */
    public boolean removeEmployeeFromDept(int employeeId) throws SQLException {
        String sql = "UPDATE employees SET department_id=NULL WHERE employee_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, employeeId);
            return ps.executeUpdate() > 0;
        }
    }
 
    private Department map(ResultSet rs) throws SQLException {
        return new Department(
            rs.getInt   ("department_id"),
            rs.getString("dept_name"),
            rs.getString("dept_code"),
            rs.getString("location")
        );
    }
}

