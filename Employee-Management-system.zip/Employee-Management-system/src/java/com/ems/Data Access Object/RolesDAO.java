package com.ems.db;

    
import ems.db.DBConnection;
import ems.model.Role;
 
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
 
public class RoleDAO {
 
    
    public boolean addRole(Role role) throws SQLException {
        String sql = "INSERT INTO roles(role_name, role_level, description) VALUES (?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, role.getRoleName());
            ps.setInt   (2, role.getRoleLevel());
            ps.setString(3, role.getDescription());
            return ps.executeUpdate() > 0;
        }
    }
 
    public List<Role> getAllRoles() throws SQLException {
        List<Role> list = new ArrayList<>();
        String sql = "SELECT * FROM roles ORDER BY role_level, role_name";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }
 
    
    public Role getRoleById(int id) throws SQLException {
        String sql = "SELECT * FROM roles WHERE role_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }
 

    public boolean updateRole(Role role) throws SQLException {
        String sql = "UPDATE roles SET role_name=?, role_level=?, description=? WHERE role_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, role.getRoleName());
            ps.setInt   (2, role.getRoleLevel());
            ps.setString(3, role.getDescription());
            ps.setInt   (4, role.getRoleId());
            return ps.executeUpdate() > 0;
        }
    }
 
   
    public boolean deleteRole(int id) throws SQLException {
        String sql = "DELETE FROM roles WHERE role_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
 
 
    private Role map(ResultSet rs) throws SQLException {
        return new Role(
            rs.getInt   ("role_id"),
            rs.getString("role_name"),
            rs.getInt   ("role_level"),
            rs.getString("description")
        );
    }
}
}
