
package com.ems.dao;


   import ems.db.DBConnection;
import ems.model.Payroll;
 
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
 
public class PayrollDAO {
 
    private static final String BASE_SELECT =
        "SELECT p.*, e.first_name || ' ' || e.last_name AS employee_name " +
        "FROM payroll p " +
        "JOIN employees e ON p.employee_id = e.employee_id ";
 
   
    //Creates a payslip for one employee for a given pay period./
    public boolean generatePayslip(Payroll payroll) throws SQLException {
        String sql =
            "INSERT INTO payroll(employee_id,basic_salary,allowances,deductions," +
            "pay_period,pay_status,notes) VALUES (?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt   (1, payroll.getEmployeeId());
            ps.setDouble(2, payroll.getBasicSalary());
            ps.setDouble(3, payroll.getAllowances());
            ps.setDouble(4, payroll.getDeductions());
            ps.setDate  (5, new java.sql.Date(payroll.getPayPeriod().getTime()));
            ps.setString(6, payroll.getPayStatus() != null ? payroll.getPayStatus() : "PENDING");
            ps.setString(7, payroll.getNotes());
            return ps.executeUpdate() > 0;
        }
    }
 
    /**Creates payslips for all active employees in one pay period. */
    public int generatePayrollForAll(double basicSalary, double allowances,
                                     double deductions, java.util.Date period)
            throws SQLException {
        // collect active employee IDs first
        List<Integer> ids = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(
                     "SELECT employee_id FROM employees WHERE status='ACTIVE'")) {
            while (rs.next()) ids.add(rs.getInt(1));
        }
 
        String sql =
            "INSERT INTO payroll(employee_id,basic_salary,allowances,deductions," +
            "pay_period,pay_status) VALUES (?,?,?,?,?,'PENDING')";
        int count = 0;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            java.sql.Date sqlDate = new java.sql.Date(period.getTime());
            for (int empId : ids) {
                ps.setInt   (1, empId);
                ps.setDouble(2, basicSalary);
                ps.setDouble(3, allowances);
                ps.setDouble(4, deductions);
                ps.setDate  (5, sqlDate);
                count += ps.executeUpdate();
            }
        }
        return count;
    }
 
   
    public List<Payroll> getAllPayroll() throws SQLException {
        List<Payroll> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(
                     BASE_SELECT + "ORDER BY p.pay_period DESC, employee_name")) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }
 
    
    public List<Payroll> getSalaryHistory(int employeeId) throws SQLException {
        List<Payroll> list = new ArrayList<>();
        String sql = BASE_SELECT + "WHERE p.employee_id=? ORDER BY p.pay_period DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, employeeId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }
 
   
    public List<Payroll> getPayrollByPeriod(java.util.Date period) throws SQLException {
        List<Payroll> list = new ArrayList<>();
        String sql = BASE_SELECT + "WHERE p.pay_period=? ORDER BY employee_name";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, new java.sql.Date(period.getTime()));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }
 
 
    public Payroll getPayrollById(int id) throws SQLException {
        String sql = BASE_SELECT + "WHERE p.payroll_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }
 
   
    public boolean updatePayroll(Payroll payroll) throws SQLException {
        String sql =
            "UPDATE payroll SET basic_salary=?,allowances=?,deductions=?," +
            "pay_period=?,pay_status=?,notes=? WHERE payroll_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDouble(1, payroll.getBasicSalary());
            ps.setDouble(2, payroll.getAllowances());
            ps.setDouble(3, payroll.getDeductions());
            ps.setDate  (4, new java.sql.Date(payroll.getPayPeriod().getTime()));
            ps.setString(5, payroll.getPayStatus());
            ps.setString(6, payroll.getNotes());
            ps.setInt   (7, payroll.getPayrollId());
            return ps.executeUpdate() > 0;
        }
    }
 
    public boolean markAsPaid(int payrollId) throws SQLException {
        String sql = "UPDATE payroll SET pay_status='PAID' WHERE payroll_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, payrollId);
            return ps.executeUpdate() > 0;
        }
    }
 
   
    public boolean deletePayroll(int id) throws SQLException {
        String sql = "DELETE FROM payroll WHERE payroll_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
 
   
    private Payroll map(ResultSet rs) throws SQLException {
        Payroll p = new Payroll();
        p.setPayrollId   (rs.getInt   ("payroll_id"));
        p.setEmployeeId  (rs.getInt   ("employee_id"));
        p.setEmployeeName(rs.getString("employee_name"));
        p.setBasicSalary (rs.getDouble("basic_salary"));
        p.setAllowances  (rs.getDouble("allowances"));
        p.setDeductions  (rs.getDouble("deductions"));
        p.setPayPeriod   (rs.getDate  ("pay_period"));
        p.setPayStatus   (rs.getString("pay_status"));
        p.setNotes       (rs.getString("notes"));
        return p;
    }
} 

