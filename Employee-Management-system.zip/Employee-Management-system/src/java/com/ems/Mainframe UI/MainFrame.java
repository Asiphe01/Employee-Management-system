package ems.ui;
 
import ems.dao.*;
import ems.db.DBInitializer;
import ems.model.*;
 
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.List;
 

public class MainFrame extends JFrame {
 
    private final EmployeeDAO   empDAO   = new EmployeeDAO();
    private final DepartmentDAO deptDAO  = new DepartmentDAO();
    private final RoleDAO       roleDAO  = new RoleDAO();
    private final PayrollDAO    payDAO   = new PayrollDAO();
 
    public MainFrame() {
        setTitle("Employee Management System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 680);
        setLocationRelativeTo(null);
 
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Employees",   buildEmployeePanel());
        tabs.addTab("Departments", buildDepartmentPanel());
        tabs.addTab("Roles",       buildRolePanel());
        tabs.addTab("Payroll",     buildPayrollPanel());
 
        add(tabs);
        setVisible(true);
    }
 
  
 
    private DefaultTableModel empModel;
    private JTable empTable;
 
    private JPanel buildEmployeePanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
 
        // search bar
        JTextField searchField = new JTextField(20);
        JButton    searchBtn   = new JButton("Search");
        JButton    refreshBtn  = new JButton("Show All");
        JPanel     searchBar   = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchBar.add(new JLabel("Search:"));
        searchBar.add(searchField);
        searchBar.add(searchBtn);
        searchBar.add(refreshBtn);
 
        // table
        String[] cols = {"ID","First Name","Last Name","Email","Phone",
                         "Hire Date","Department","Role","Status"};
        empModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        empTable = new JTable(empModel);
        empTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        loadEmployees(null);
 
       
        JButton addBtn    = new JButton("Add");
        JButton editBtn   = new JButton("Edit");
        JButton deleteBtn = new JButton("Delete");
        JPanel  btnPanel  = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.add(addBtn); btnPanel.add(editBtn); btnPanel.add(deleteBtn);
 
        panel.add(searchBar,                      BorderLayout.NORTH);
        panel.add(new JScrollPane(empTable),      BorderLayout.CENTER);
        panel.add(btnPanel,                       BorderLayout.SOUTH);
 
        
        searchBtn.addActionListener(e -> loadEmployees(searchField.getText().trim()));
        refreshBtn.addActionListener(e -> { searchField.setText(""); loadEmployees(null); });
        addBtn.addActionListener   (e -> openEmployeeDialog(null));
        editBtn.addActionListener  (e -> {
            int row = empTable.getSelectedRow();
            if (row < 0) { warn("Select an employee first."); return; }
            int id = (int) empModel.getValueAt(row, 0);
            try { openEmployeeDialog(empDAO.getEmployeeById(id)); }
            catch (Exception ex) { error(ex); }
        });
        deleteBtn.addActionListener(e -> {
            int row = empTable.getSelectedRow();
            if (row < 0) { warn("Select an employee first."); return; }
            int id = (int) empModel.getValueAt(row, 0);
            if (confirm("Delete employee #" + id + "?")) {
                try { empDAO.deleteEmployee(id); loadEmployees(null); }
                catch (Exception ex) { error(ex); }
            }
        });
        return panel;
    }
 
    private void loadEmployees(String kw) {
        empModel.setRowCount(0);
        try {
            List<Employee> list = (kw == null || kw.isEmpty())
                    ? empDAO.getAllEmployees()
                    : empDAO.searchEmployees(kw);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            for (Employee e : list) {
                empModel.addRow(new Object[]{
                    e.getEmployeeId(), e.getFirstName(), e.getLastName(),
                    e.getEmail(), e.getPhone(),
                    e.getHireDate() != null ? sdf.format(e.getHireDate()) : "",
                    e.getDepartmentName(), e.getRoleName(), e.getStatus()
                });
            }
        } catch (Exception ex) { error(ex); }
    }
 
    private void openEmployeeDialog(Employee existing) {
        boolean isEdit = existing != null;
        JDialog dlg = new JDialog(this, isEdit ? "Edit Employee" : "Add Employee", true);
        dlg.setSize(420, 380); dlg.setLocationRelativeTo(this);
        dlg.setLayout(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4,4,4,4); gc.fill = GridBagConstraints.HORIZONTAL;
 
        JTextField tfFirst = new JTextField(15);
        JTextField tfLast  = new JTextField(15);
        JTextField tfEmail = new JTextField(15);
        JTextField tfPhone = new JTextField(15);
        JTextField tfDate  = new JTextField("yyyy-MM-dd", 15);
        JComboBox<Department> cbDept = new JComboBox<>();
        JComboBox<Role>       cbRole = new JComboBox<>();
        JComboBox<String>     cbStatus = new JComboBox<>(
                new String[]{"ACTIVE","INACTIVE","ON_LEAVE"});
 
        try {
            deptDAO.getAllDepartments().forEach(cbDept::addItem);
            roleDAO.getAllRoles().forEach(cbRole::addItem);
        } catch (Exception ex) { error(ex); }
 
        if (isEdit) {
            tfFirst.setText(existing.getFirstName());
            tfLast .setText(existing.getLastName());
            tfEmail.setText(existing.getEmail());
            tfPhone.setText(existing.getPhone());
            if (existing.getHireDate() != null)
                tfDate.setText(new SimpleDateFormat("yyyy-MM-dd")
                        .format(existing.getHireDate()));
            cbStatus.setSelectedItem(existing.getStatus());
            // pre-select dept and role
            for (int i = 0; i < cbDept.getItemCount(); i++)
                if (cbDept.getItemAt(i).getDepartmentId() == existing.getDepartmentId())
                    { cbDept.setSelectedIndex(i); break; }
            for (int i = 0; i < cbRole.getItemCount(); i++)
                if (cbRole.getItemAt(i).getRoleId() == existing.getRoleId())
                    { cbRole.setSelectedIndex(i); break; }
        }
 
        String[][] fields = {{"First Name","Last Name"},{"Email","Phone"},
                             {"Hire Date (yyyy-MM-dd)","Status"}};
        JComponent[][] comps = {{tfFirst, tfLast},{tfEmail, tfPhone},{tfDate, cbStatus}};
 
        int row = 0;
        for (int fi = 0; fi < fields.length; fi++, row++) {
            for (int col = 0; col < 2; col++) {
                gc.gridx = col*2; gc.gridy = row;
                dlg.add(new JLabel(fields[fi][col]+":"), gc);
                gc.gridx = col*2+1;
                dlg.add(comps[fi][col], gc);
            }
        }
        gc.gridx=0; gc.gridy=row; dlg.add(new JLabel("Department:"), gc);
        gc.gridx=1; dlg.add(cbDept, gc);
        gc.gridx=2; dlg.add(new JLabel("Role:"), gc);
        gc.gridx=3; dlg.add(cbRole, gc);
 
        JButton saveBtn = new JButton("Save");
        gc.gridx=0; gc.gridy=++row; gc.gridwidth=4;
        dlg.add(saveBtn, gc);
 
        saveBtn.addActionListener(e -> {
            try {
                Employee emp = isEdit ? existing : new Employee();
                emp.setFirstName   (tfFirst.getText().trim());
                emp.setLastName    (tfLast .getText().trim());
                emp.setEmail       (tfEmail.getText().trim());
                emp.setPhone       (tfPhone.getText().trim());
                emp.setHireDate    (new SimpleDateFormat("yyyy-MM-dd")
                                   .parse(tfDate.getText().trim()));
                emp.setStatus      ((String) cbStatus.getSelectedItem());
                Department d = (Department) cbDept.getSelectedItem();
                Role       r = (Role)       cbRole .getSelectedItem();
                emp.setDepartmentId(d != null ? d.getDepartmentId() : 0);
                emp.setRoleId      (r != null ? r.getRoleId()       : 0);
 
                boolean ok = isEdit ? empDAO.updateEmployee(emp)
                                    : empDAO.addEmployee(emp);
                if (ok) { loadEmployees(null); dlg.dispose(); }
                else    warn("Operation failed.");
            } catch (Exception ex) { error(ex); }
        });
        dlg.setVisible(true);
    }
 
 
 
    private DefaultTableModel deptModel;
    private JTable deptTable;
 
    private JPanel buildDepartmentPanel() {
        JPanel panel = new JPanel(new BorderLayout(5,5));
        panel.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
 
        String[] cols = {"ID","Name","Code","Location"};
        deptModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        
        deptTable = new JTable(deptModel);
        deptTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        loadDepartments();
 
        JButton addBtn    = new JButton("Add");
        JButton editBtn   = new JButton("Edit");
        JButton deleteBtn = new JButton("Delete");
        JPanel  btnPanel  = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.add(addBtn); btnPanel.add(editBtn); btnPanel.add(deleteBtn);
 
        panel.add(new JScrollPane(deptTable), BorderLayout.CENTER);
        panel.add(btnPanel,                   BorderLayout.SOUTH);
 
        addBtn.addActionListener   (e -> openDeptDialog(null));
        editBtn.addActionListener  (e -> {
            int row = deptTable.getSelectedRow();
            if (row < 0) { warn("Select a department."); return; }
            int id = (int) deptModel.getValueAt(row, 0);
            try { openDeptDialog(deptDAO.getDepartmentById(id)); }
            catch (Exception ex) { error(ex); }
        });
        deleteBtn.addActionListener(e -> {
            int row = deptTable.getSelectedRow();
            if (row < 0) { warn("Select a department."); return; }
            int id = (int) deptModel.getValueAt(row, 0);
            if (confirm("Delete department #" + id + "?")) {
                try { deptDAO.deleteDepartment(id); loadDepartments(); }
                catch (Exception ex) { error(ex); }
            }
        });
        return panel;
    }
 
    private void loadDepartments() {
        deptModel.setRowCount(0);
        try {
            for (Department d : deptDAO.getAllDepartments())
                deptModel.addRow(new Object[]{d.getDepartmentId(),
                        d.getDeptName(), d.getDeptCode(), d.getLocation()});
        } catch (Exception ex) { error(ex); }
    }
 
    private void openDeptDialog(Department existing) {
        boolean isEdit = existing != null;
        JDialog dlg = new JDialog(this, isEdit ? "Edit Department" : "Add Department", true);
        dlg.setSize(340, 200); dlg.setLocationRelativeTo(this);
        dlg.setLayout(new GridLayout(4, 2, 6, 6));
        dlg.getRootPane().setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
 
        JTextField tfName = new JTextField(existing != null ? existing.getDeptName() : "");
        JTextField tfCode = new JTextField(existing != null ? existing.getDeptCode() : "");
        JTextField tfLoc  = new JTextField(existing != null ? existing.getLocation() : "");
 
        dlg.add(new JLabel("Name:"));     dlg.add(tfName);
        dlg.add(new JLabel("Code:"));     dlg.add(tfCode);
        dlg.add(new JLabel("Location:")); dlg.add(tfLoc);
        JButton saveBtn = new JButton("Save");
        dlg.add(new JLabel()); dlg.add(saveBtn);
 
        saveBtn.addActionListener(e -> {
            try {
                Department d = isEdit ? existing : new Department();
                d.setDeptName(tfName.getText().trim());
                d.setDeptCode(tfCode.getText().trim());
                d.setLocation(tfLoc .getText().trim());
                boolean ok = isEdit ? deptDAO.updateDepartment(d)
                                    : deptDAO.addDepartment(d);
                if (ok) { loadDepartments(); dlg.dispose(); }
                else    warn("Operation failed.");
            } catch (Exception ex) { error(ex); }
        });
        dlg.setVisible(true);
    }
 
 
    private DefaultTableModel roleModel;
 
    private JPanel buildRolePanel() {
        JPanel panel = new JPanel(new BorderLayout(5,5));
        panel.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
 
        String[] cols = {"ID","Role Name","Level","Description"};
        roleModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable roleTable = new JTable(roleModel);
        roleTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        loadRoles();
 
        JButton addBtn    = new JButton("Add");
        JButton editBtn   = new JButton("Edit");
        JButton deleteBtn = new JButton("Delete");
        JPanel  btnPanel  = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.add(addBtn); btnPanel.add(editBtn); btnPanel.add(deleteBtn);
 
        panel.add(new JScrollPane(roleTable), BorderLayout.CENTER);
        panel.add(btnPanel,                   BorderLayout.SOUTH);
 
        addBtn.addActionListener(e -> openRoleDialog(null, roleTable));
        editBtn.addActionListener(e -> {
            int row = roleTable.getSelectedRow();
            if (row < 0) { warn("Select a role."); return; }
            int id = (int) roleModel.getValueAt(row, 0);
            try { openRoleDialog(roleDAO.getRoleById(id), roleTable); }
            catch (Exception ex) { error(ex); }
        });
        deleteBtn.addActionListener(e -> {
            int row = roleTable.getSelectedRow();
            if (row < 0) { warn("Select a role."); return; }
            int id = (int) roleModel.getValueAt(row, 0);
            if (confirm("Delete role #" + id + "?")) {
                try { roleDAO.deleteRole(id); loadRoles(); }
                catch (Exception ex) { error(ex); }
            }
        });
        return panel;
    }
 
    private void loadRoles() {
        roleModel.setRowCount(0);
        try {
            for (Role r : roleDAO.getAllRoles())
                roleModel.addRow(new Object[]{r.getRoleId(),
                        r.getRoleName(), r.getRoleLevel(), r.getDescription()});
        } catch (Exception ex) { error(ex); }
    }
 
    private void openRoleDialog(Role existing, JTable table) {
        boolean isEdit = existing != null;
        JDialog dlg = new JDialog(this, isEdit ? "Edit Role" : "Add Role", true);
        dlg.setSize(360, 210); dlg.setLocationRelativeTo(this);
        dlg.setLayout(new GridLayout(4, 2, 6, 6));
        dlg.getRootPane().setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
 
        JTextField tfName  = new JTextField(existing != null ? existing.getRoleName() : "");
        JSpinner   spLevel = new JSpinner(new SpinnerNumberModel(
                existing != null ? existing.getRoleLevel() : 1, 1, 10, 1));
        JTextField tfDesc  = new JTextField(existing != null ? existing.getDescription() : "");
 
        dlg.add(new JLabel("Role Name:"));   dlg.add(tfName);
        dlg.add(new JLabel("Level (1-10):")); dlg.add(spLevel);
        dlg.add(new JLabel("Description:")); dlg.add(tfDesc);
        JButton saveBtn = new JButton("Save");
        dlg.add(new JLabel()); dlg.add(saveBtn);
 
        saveBtn.addActionListener(e -> {
            try {
                Role r = isEdit ? existing : new Role();
                r.setRoleName   (tfName .getText().trim());
                r.setRoleLevel  ((int) spLevel.getValue());
                r.setDescription(tfDesc.getText().trim());
                boolean ok = isEdit ? roleDAO.updateRole(r) : roleDAO.addRole(r);
                if (ok) { loadRoles(); dlg.dispose(); }
                else    warn("Operation failed.");
            } catch (Exception ex) { error(ex); }
        });
        dlg.setVisible(true);
    }
 
    
 
    private DefaultTableModel payModel;
 
    private JPanel buildPayrollPanel() {
        JPanel panel = new JPanel(new BorderLayout(5,5));
        panel.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
 
        String[] cols = {"ID","Employee","Basic Salary","Allowances",
                         "Deductions","Net Salary","Pay Period","Status"};
        payModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable payTable = new JTable(payModel);
        payTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        loadPayroll();
 
        JButton genBtn    = new JButton("Generate Payslip");
        JButton editBtn   = new JButton("Edit");
        JButton paidBtn   = new JButton("Mark Paid");
        JButton deleteBtn = new JButton("Delete");
        JButton histBtn   = new JButton("View History");
        JPanel  btnPanel  = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnPanel.add(genBtn); btnPanel.add(editBtn);
        btnPanel.add(paidBtn); btnPanel.add(histBtn); btnPanel.add(deleteBtn);
 
        panel.add(new JScrollPane(payTable), BorderLayout.CENTER);
        panel.add(btnPanel,                  BorderLayout.SOUTH);
 
        genBtn.addActionListener(e -> openPayrollDialog(null, payTable));
        editBtn.addActionListener(e -> {
            int row = payTable.getSelectedRow();
            if (row < 0) { warn("Select a payslip."); return; }
            int id = (int) payModel.getValueAt(row, 0);
            try { openPayrollDialog(payDAO.getPayrollById(id), payTable); }
            catch (Exception ex) { error(ex); }
        });
        paidBtn.addActionListener(e -> {
            int row = payTable.getSelectedRow();
            if (row < 0) { warn("Select a payslip."); return; }
            int id = (int) payModel.getValueAt(row, 0);
            try { payDAO.markAsPaid(id); loadPayroll(); }
            catch (Exception ex) { error(ex); }
        });
        deleteBtn.addActionListener(e -> {
            int row = payTable.getSelectedRow();
            if (row < 0) { warn("Select a payslip."); return; }
            int id = (int) payModel.getValueAt(row, 0);
            if (confirm("Delete payslip #" + id + "?")) {
                try { payDAO.deletePayroll(id); loadPayroll(); }
                catch (Exception ex) { error(ex); }
            }
        });
        histBtn.addActionListener(e -> showPayrollHistory());
        return panel;
    }
 
    private void loadPayroll() {
        payModel.setRowCount(0);
        try {
            for (Payroll p : payDAO.getAllPayroll())
                payModel.addRow(payRow(p));
        } catch (Exception ex) { error(ex); }
    }
 
    private Object[] payRow(Payroll p) {
        return new Object[]{
            p.getPayrollId(), p.getEmployeeName(),
            String.format("%.2f", p.getBasicSalary()),
            String.format("%.2f", p.getAllowances()),
            String.format("%.2f", p.getDeductions()),
            String.format("%.2f", p.getNetSalary()),
            new SimpleDateFormat("yyyy-MM-dd").format(p.getPayPeriod()),
            p.getPayStatus()
        };
    }
 
    private void openPayrollDialog(Payroll existing, JTable table) {
        boolean isEdit = existing != null;
        JDialog dlg = new JDialog(this,
                isEdit ? "Edit Payslip" : "Generate Payslip", true);
        dlg.setSize(400, 300); dlg.setLocationRelativeTo(this);
        dlg.setLayout(new GridLayout(7, 2, 6, 6));
        dlg.getRootPane().setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
 
        JComboBox<Employee> cbEmp = new JComboBox<>();
        try { empDAO.getAllEmployees().forEach(cbEmp::addItem); }
        catch (Exception ex) { error(ex); }
 
        JTextField tfBasic  = new JTextField("0.00");
        JTextField tfAllow  = new JTextField("0.00");
        JTextField tfDeduct = new JTextField("0.00");
        JTextField tfPeriod = new JTextField(
                new SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()));
        JComboBox<String> cbStatus = new JComboBox<>(
                new String[]{"PENDING","PAID","CANCELLED"});
        JTextField tfNotes  = new JTextField();
 
        if (isEdit) {
            for (int i = 0; i < cbEmp.getItemCount(); i++)
                if (cbEmp.getItemAt(i).getEmployeeId() == existing.getEmployeeId())
                    { cbEmp.setSelectedIndex(i); break; }
            tfBasic .setText(String.format("%.2f", existing.getBasicSalary()));
            tfAllow .setText(String.format("%.2f", existing.getAllowances()));
            tfDeduct.setText(String.format("%.2f", existing.getDeductions()));
            tfPeriod.setText(new SimpleDateFormat("yyyy-MM-dd")
                    .format(existing.getPayPeriod()));
            cbStatus.setSelectedItem(existing.getPayStatus());
            tfNotes.setText(existing.getNotes());
        }
 
        dlg.add(new JLabel("Employee:"));       dlg.add(cbEmp);
        dlg.add(new JLabel("Basic Salary:"));   dlg.add(tfBasic);
        dlg.add(new JLabel("Allowances:"));     dlg.add(tfAllow);
        dlg.add(new JLabel("Deductions:"));     dlg.add(tfDeduct);
        dlg.add(new JLabel("Pay Period (yyyy-MM-dd):")); dlg.add(tfPeriod);
        dlg.add(new JLabel("Status:"));         dlg.add(cbStatus);
        dlg.add(new JLabel("Notes:"));          dlg.add(tfNotes);
 
        JButton saveBtn = new JButton("Save");
        dlg.add(new JLabel()); dlg.add(saveBtn);
 
        saveBtn.addActionListener(e -> {
            try {
                Payroll p = isEdit ? existing : new Payroll();
                Employee sel = (Employee) cbEmp.getSelectedItem();
                if (sel != null) p.setEmployeeId(sel.getEmployeeId());
                p.setBasicSalary(Double.parseDouble(tfBasic .getText().trim()));
                p.setAllowances (Double.parseDouble(tfAllow .getText().trim()));
                p.setDeductions (Double.parseDouble(tfDeduct.getText().trim()));
                p.setPayPeriod  (new SimpleDateFormat("yyyy-MM-dd")
                                .parse(tfPeriod.getText().trim()));
                p.setPayStatus  ((String) cbStatus.getSelectedItem());
                p.setNotes      (tfNotes.getText().trim());
 
                boolean ok = isEdit ? payDAO.updatePayroll(p)
                                    : payDAO.generatePayslip(p);
                if (ok) { loadPayroll(); dlg.dispose(); }
                else    warn("Operation failed.");
            } catch (Exception ex) { error(ex); }
        });
        dlg.setVisible(true);
    }
 
    private void showPayrollHistory() {
        // Pick an employee to view history for
        try {
            List<Employee> emps = empDAO.getAllEmployees();
            Employee[] arr = emps.toArray(new Employee[0]);
            Employee chosen = (Employee) JOptionPane.showInputDialog(
                    this, "Select Employee:", "Salary History",
                    JOptionPane.PLAIN_MESSAGE, null, arr,
                    arr.length > 0 ? arr[0] : null);
            if (chosen == null) return;
 
            List<Payroll> hist = payDAO.getSalaryHistory(chosen.getEmployeeId());
            String[] cols = {"ID","Basic","Allowances","Deductions","Net","Period","Status"};
            DefaultTableModel m = new DefaultTableModel(cols, 0);
            for (Payroll p : hist)
                m.addRow(new Object[]{
                    p.getPayrollId(),
                    String.format("%.2f", p.getBasicSalary()),
                    String.format("%.2f", p.getAllowances()),
                    String.format("%.2f", p.getDeductions()),
                    String.format("%.2f", p.getNetSalary()),
                    new SimpleDateFormat("yyyy-MM-dd").format(p.getPayPeriod()),
                    p.getPayStatus()
                });
            JTable t = new JTable(m);
            JOptionPane.showMessageDialog(this, new JScrollPane(t),
                    "Salary History – " + chosen.getFullName(),
                    JOptionPane.PLAIN_MESSAGE);
        } catch (Exception ex) { error(ex); }
    }
 
   //helper
 
    private void warn(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Warning",
                JOptionPane.WARNING_MESSAGE);
    }
    private void error(Exception ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace();
    }
    private boolean confirm(String msg) {
        return JOptionPane.showConfirmDialog(this, msg, "Confirm",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }
 
 //Enpoint
    public static void main(String[] args) {
        // Initialise DB tables
        DBInitializer.init();
 
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) {}
            new MainFrame();
        });
    }
}
   

