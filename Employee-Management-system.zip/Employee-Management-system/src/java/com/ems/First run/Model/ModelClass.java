
package com.ems.model;

   
    import java.util.Date;
 

class Department {
    private int    departmentId;
    private String deptName;
    private String deptCode;
    private String location;
 
    public Department() {}
    public Department(int departmentId, String deptName,
                      String deptCode, String location) {
        this.departmentId = departmentId;
        this.deptName     = deptName;
        this.deptCode     = deptCode;
        this.location     = location;
    }
 
    public int    getDepartmentId()             { return departmentId; }
    public void   setDepartmentId(int id)       { this.departmentId = id; }
    public String getDeptName()                 { return deptName; }
    public void   setDeptName(String n)         { this.deptName = n; }
    public String getDeptCode()                 { return deptCode; }
    public void   setDeptCode(String c)         { this.deptCode = c; }
    public String getLocation()                 { return location; }
    public void   setLocation(String l)         { this.location = l; }
 
    @Override public String toString()          { return deptName; }
}
 

class Role {
    private int    roleId;
    private String roleName;
    private int    roleLevel;
    private String description;
 
    public Role() {}
    public Role(int roleId, String roleName, int roleLevel, String description) {
        this.roleId      = roleId;
        this.roleName    = roleName;
        this.roleLevel   = roleLevel;
        this.description = description;
    }
 
    public int    getRoleId()               { return roleId; }
    public void   setRoleId(int id)         { this.roleId = id; }
    public String getRoleName()             { return roleName; }
    public void   setRoleName(String n)     { this.roleName = n; }
    public int    getRoleLevel()            { return roleLevel; }
    public void   setRoleLevel(int l)       { this.roleLevel = l; }
    public String getDescription()          { return description; }
    public void   setDescription(String d)  { this.description = d; }
 
    @Override public String toString()      { return roleName; }
}
 

class Employee {
    private int        employeeId;
    private String     firstName;
    private String     lastName;
    private String     email;
    private String     phone;
    private Date       hireDate;
    private int        departmentId;
    private String     departmentName;   // joined
    private int        roleId;
    private String     roleName;         // joined
    private String     status;
 
    public Employee() {}
 
    public int    getEmployeeId()                   { return employeeId; }
    public void   setEmployeeId(int id)             { this.employeeId = id; }
    public String getFirstName()                    { return firstName; }
    public void   setFirstName(String n)            { this.firstName = n; }
    public String getLastName()                     { return lastName; }
    public void   setLastName(String n)             { this.lastName = n; }
    public String getFullName()                     { return firstName + " " + lastName; }
    public String getEmail()                        { return email; }
    public void   setEmail(String e)                { this.email = e; }
    public String getPhone()                        { return phone; }
    public void   setPhone(String p)                { this.phone = p; }
    public Date   getHireDate()                     { return hireDate; }
    public void   setHireDate(Date d)               { this.hireDate = d; }
    public int    getDepartmentId()                 { return departmentId; }
    public void   setDepartmentId(int id)           { this.departmentId = id; }
    public String getDepartmentName()               { return departmentName; }
    public void   setDepartmentName(String n)       { this.departmentName = n; }
    public int    getRoleId()                       { return roleId; }
    public void   setRoleId(int id)                 { this.roleId = id; }
    public String getRoleName()                     { return roleName; }
    public void   setRoleName(String n)             { this.roleName = n; }
    public String getStatus()                       { return status; }
    public void   setStatus(String s)               { this.status = s; }
 
    @Override public String toString() { return getFullName(); }
}
 

class Payroll {
    private int     payrollId;
    private int     employeeId;
    private String  employeeName;   // joined
    private double  basicSalary;
    private double  allowances;
    private double  deductions;
    private Date    payPeriod;
    private String  payStatus;
    private String  notes;
 
    public Payroll() {}
 
    public int    getPayrollId()                { return payrollId; }
    public void   setPayrollId(int id)          { this.payrollId = id; }
    public int    getEmployeeId()               { return employeeId; }
    public void   setEmployeeId(int id)         { this.employeeId = id; }
    public String getEmployeeName()             { return employeeName; }
    public void   setEmployeeName(String n)     { this.employeeName = n; }
    public double getBasicSalary()              { return basicSalary; }
    public void   setBasicSalary(double s)      { this.basicSalary = s; }
    public double getAllowances()               { return allowances; }
    public void   setAllowances(double a)       { this.allowances = a; }
    public double getDeductions()               { return deductions; }
    public void   setDeductions(double d)       { this.deductions = d; }
    public double getNetSalary()               { return basicSalary + allowances - deductions; }
    public Date   getPayPeriod()               { return payPeriod; }
    public void   setPayPeriod(Date p)         { this.payPeriod = p; }
    public String getPayStatus()               { return payStatus; }
    public void   setPayStatus(String s)       { this.payStatus = s; }
    public String getNotes()                   { return notes; }
    public void   setNotes(String n)           { this.notes = n; }
}

    

